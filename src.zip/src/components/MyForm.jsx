import React from 'react';
import {
  BrowserRouter as Router,
  Switch, Route, Link,
  useRouteMatch, useParams,
} from 'react-router-dom';
import { useDispatch } from 'react-redux';
import {
  Form, Icon, Input, Button,
} from 'antd';
import 'antd/dist/antd.css';
import { login } from '../actions';

// const dispatch = useDispatch();
// dispatch()
const MyForm = (props) => {
  const { form } = props;
  const dispatch = useDispatch();
  const handleSubmit = (e) => {
    e.preventDefault();
    form.validateFields((err, values) => {
      if (!err) {
        dispatch(login(values.username, values.password));
      }
    });
  };

  const { getFieldDecorator } = form;
  return (
    <Form onSubmit={handleSubmit} className="login-form">
      <Form.Item>
        {getFieldDecorator('username', {
          rules: [{ required: true, message: 'Please input your username!' }],
        })(
          <Input
            prefix={<Icon type="user" style={{ color: 'rgba(0,0,0,.25)' }} />}
            placeholder="Username"
          />,
        )}
      </Form.Item>
      <Form.Item>
        {getFieldDecorator('password', {
          rules: [{ required: true, message: 'Please input your Password!' }],
        })(
          <Input
            prefix={<Icon type="lock" style={{ color: 'rgba(0,0,0,.25)' }} />}
            type="password"
            placeholder="Password"
          />,
        )}
      </Form.Item>
      <Form.Item>
        <Button type="primary" htmlType="submit" className="login-form-button">
          Log in
        </Button>
      </Form.Item>
    </Form>
  );
};

const Home = () => {
  return (
    <Router>
      <div>
        <nav>
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/about">About</Link>
            </li>
            <li>
              <Link to="/topics">Topics</Link>
            </li>
          </ul>
        </nav>

        <Switch>
          <Route path="/about">
            <About>
              <h1>Hello World!</h1>
            </About>
            <Route path="topics">
              <Topics />
            </Route>
            <Route path="/">
              <Home />
              <h1>Truallala</h1>
            </Route>
          </Route>
        </Switch>
      </div>
    </Router>
  );
};

const About = () => {
  return <h2>About</h2>;
};

const Topics = () => {
  let match = useRouteMatch();

  return (
    <div>
      <h2>Topics</h2>

      <ul>
        <li>
          <Link to= {`${match.url}/components`}>Components</Link>
        </li>
        <li>
          <Link to={`${match.url}/props-v-state`}>
            Props v. State
          </Link>
        </li>
      </ul>

      <Switch>
        <Route path={`${match.path}/:topicId`}>
          <Topics />
        </Route>
        <Route path={`${match.path}`}>
          <h3>Please select a topic.</h3>
        </Route>
      </Switch>
    </div>
  )
}

const mapStateToProps = (state) => ({
  token: state.token,
});

export default Form.create({ name: 'normal_login' })(MyForm);
