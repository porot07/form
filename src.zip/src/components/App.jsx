import React, { useEffect } from 'react';
import { Row, Col } from 'antd';
import 'antd/dist/antd.css';
import '../css/style.css';

import MyForm from './MyForm';

export default class App extends React.Component {
  render() {
    return (
      <div className="height">
        <Row type="flex" justify="center" align="bottom">
          <div id="components-form-login">
            <MyForm />
          </div>
        </Row>
      </div>
    );
  }
}
