import { handleActions } from 'redux-actions';
// import { reducer as formReducer } from 'redux-form';
import { combineReducers } from 'redux';
import * as actions from '../actions';

const loginData = handleActions({
  [actions.loginSuccess](state, { payload: { token } }) {
    return {
      ...state,
      token,
    };
  },
}, {});

export default combineReducers({
  loginData,
});
